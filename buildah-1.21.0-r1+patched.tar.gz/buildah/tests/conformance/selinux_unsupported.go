// +build !linux

package conformance

func selinuxMountFlag() string {
	return ""
}
